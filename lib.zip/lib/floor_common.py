# -*- coding: utf-8 -*-

import json
import math

from Autodesk.Revit.DB import (  # type: ignore
    BuiltInCategory,
    Color,
    ElementId,
    FilteredElementCollector,
    GraphicsStyleType,
    LinePatternElement,
    Part,
    StorageType,
)
from Autodesk.Revit.UI.Selection import ISelectionFilter  # type: ignore
from floor_i18n import tr  # type: ignore
from rf_param_schema import RFParams as P  # type: ignore
from revit_context import get_doc  # type: ignore

REINFORCEMENT_ZONES_PARAM = P.REINF_ZONES_JSON

_LEGACY_MM_LENGTH_PARAM_LIMITS = {
    P.BOTTOM_STEP: 10000.0,
    P.MAX_STRINGER_LEN: 20000.0,
}


def _require_finite_float(value, label):
    try:
        float_value = float(value)
    except Exception:
        raise ValueError(tr("invalid_number_named", name=label))

    if not math.isfinite(float_value):
        raise ValueError(tr("invalid_number_named", name=label))

    return float_value


def _require_positive_float(value, message, label):
    float_value = _require_finite_float(value, label)
    if float_value <= 0:
        raise ValueError(message)
    return float_value


def build_positions(
    min_val,
    max_val,
    base_val,
    step_val,
    end_padding_steps=0.0,
    end_tolerance=0.0,
):
    min_val = _require_finite_float(min_val, "min_val")
    max_val = _require_finite_float(max_val, "max_val")
    base_val = _require_finite_float(base_val, "base_val")
    step_val = _require_positive_float(step_val, tr("step_positive"), "step_val")
    end_padding_steps = _require_finite_float(end_padding_steps, "end_padding_steps")
    end_tolerance = _require_finite_float(end_tolerance, "end_tolerance")

    if max_val < min_val:
        raise ValueError(tr("range_min_exceeds_max"))

    positions = []

    n_start = int(math.floor((min_val - base_val) / step_val))
    current = base_val + n_start * step_val

    # Keep current near min_val to avoid extra far-left values caused by float noise.
    while current < min_val - step_val:
        current += step_val

    max_with_tail = max_val + step_val * float(end_padding_steps) + float(end_tolerance)
    while current <= max_with_tail:
        positions.append(current)
        current += step_val

    return positions


def get_id_value(obj):
    try:
        return obj.Id.IntegerValue
    except Exception:
        try:
            return obj.Id.Value
        except Exception:
            try:
                return obj.IntegerValue
            except Exception:
                return obj.Value


class FloorOrPartSelectionFilter(ISelectionFilter):
    def AllowElement(self, element):
        if not element:
            return False

        try:
            if element.Category and get_id_value(element.Category.Id) == int(
                BuiltInCategory.OST_Floors
            ):
                return True
        except Exception:
            pass

        if isinstance(element, Part):
            return True

        return False

    def AllowReference(self, reference, position):
        return True


def get_source_floor(el, visited_ids=None):
    if not el:
        return None

    if visited_ids is None:
        visited_ids = set()

    try:
        el_id_val = get_id_value(el)
        if el_id_val in visited_ids:
            return None
        visited_ids.add(el_id_val)
    except Exception:
        pass

    try:
        if el.Category and get_id_value(el.Category.Id) == int(
            BuiltInCategory.OST_Floors
        ):
            return el
    except Exception:
        pass

    if isinstance(el, Part):
        try:
            doc = get_doc()
            if not doc:
                return None
            source_ids = el.GetSourceElementIds()
            for sid in source_ids:
                host_id = sid.HostElementId
                host_el = doc.GetElement(host_id)
                if not host_el:
                    continue

                try:
                    if host_el.Category and get_id_value(host_el.Category.Id) == int(
                        BuiltInCategory.OST_Floors
                    ):
                        return host_el
                except Exception:
                    pass

                if isinstance(host_el, Part):
                    result = get_source_floor(host_el, visited_ids)
                    if result:
                        return result
        except Exception:
            return None

    return None


def read_floor_grid_params(floor):
    params = {
        P.STEP_X: get_double_param(floor, P.STEP_X),
        P.STEP_Y: get_double_param(floor, P.STEP_Y),
        P.BASE_X: get_double_param(floor, P.BASE_X),
        P.BASE_Y: get_double_param(floor, P.BASE_Y),
    }

    missing = [name for name, val in params.items() if val is None]
    if missing:
        raise Exception(tr("params_read_error", missing="\n- ".join(missing)))

    invalid = []
    for name, value in list(params.items()):
        try:
            params[name] = _require_finite_float(value, name)
        except ValueError:
            invalid.append(name)

    if invalid:
        raise Exception(tr("params_read_error", missing="\n- ".join(invalid)))

    if params[P.STEP_X] <= 0 or params[P.STEP_Y] <= 0:
        raise Exception(tr("step_positive"))

    return {
        "step_x": params[P.STEP_X],
        "step_y": params[P.STEP_Y],
        "base_x_raw": params[P.BASE_X],
        "base_y_raw": params[P.BASE_Y],
    }


def get_double_param(el, name):
    p = el.LookupParameter(name)
    if not p:
        return None
    try:
        if p.StorageType != StorageType.Double:
            return None
    except Exception:
        return None
    try:
        return p.AsDouble()
    except Exception:
        return None


def set_double_param(el, name, value):
    p = el.LookupParameter(name)
    if not p:
        return False
    try:
        if p.StorageType != StorageType.Double:
            return False
        if p.IsReadOnly:
            return False
    except Exception:
        return False
    try:
        p.Set(value)
        return True
    except Exception:
        return False


def get_string_param(el, name):
    p = el.LookupParameter(name)
    if not p:
        return None
    try:
        if p.StorageType != StorageType.String:
            return None
    except Exception:
        return None
    try:
        return p.AsString()
    except Exception:
        return None


def set_string_param(el, name, value):
    p = el.LookupParameter(name)
    if not p:
        return False
    try:
        if p.IsReadOnly:
            return False
        if p.StorageType != StorageType.String:
            return False
    except Exception:
        return False
    try:
        if value is None:
            normalized_value = ""
        elif isinstance(value, str):
            normalized_value = value
        else:
            normalized_value = str(value)
        p.Set(normalized_value)
        return True
    except Exception:
        return False


def get_mm_param(el, name, default_mm=None):
    """Читает параметр как мм.

    Поддерживает:
    - String: хранится число в мм
    - Double Length: Revit internal (ft), конвертируется в мм
    - Double Number: трактуется как мм без конвертации
    - Integer: трактуется как мм
    """
    p = el.LookupParameter(name)
    if not p:
        return default_mm

    try:
        st = p.StorageType
    except Exception:
        return default_mm

    try:
        if st == StorageType.String:
            s = p.AsString()
            if not s:
                return default_mm
            return float(str(s).replace(",", ".").strip())

        if st == StorageType.Double:
            value = float(p.AsDouble())
            if _is_length_param(p):
                if _looks_like_legacy_mm_in_length(name, value):
                    return value
                return value * 304.8
            return value

        if st == StorageType.Integer:
            return float(p.AsInteger())
    except Exception:
        return default_mm

    return default_mm


def set_mm_param(el, name, mm_value):
    """Записывает параметр из мм.

    String  -> текст в мм (целое)
    Double Length -> internal feet
    Double Number -> мм как число
    Integer -> мм как int
    """
    p = el.LookupParameter(name)
    if not p:
        return False
    if p.IsReadOnly:
        return False

    try:
        mm = float(mm_value)
    except Exception:
        return False

    try:
        st = p.StorageType
    except Exception:
        return False

    try:
        if st == StorageType.String:
            p.Set(str(int(round(mm))))
            return True

        if st == StorageType.Double:
            if _is_length_param(p):
                p.Set(mm / 304.8)
            else:
                p.Set(mm)
            return True

        if st == StorageType.Integer:
            p.Set(int(round(mm)))
            return True
    except Exception:
        return False

    return False


def normalize_legacy_mm_param(el, name):
    p = el.LookupParameter(name)
    if not p:
        return False

    try:
        if p.IsReadOnly or p.StorageType != StorageType.Double:
            return False
    except Exception:
        return False

    if not _is_length_param(p):
        return False

    try:
        raw_value = float(p.AsDouble())
    except Exception:
        return False

    if not _looks_like_legacy_mm_in_length(name, raw_value):
        return False

    try:
        p.Set(raw_value / 304.8)
        return True
    except Exception:
        return False


def _is_length_param(param):
    try:
        defn = param.Definition
    except Exception:
        return False

    try:
        from Autodesk.Revit.DB import SpecTypeId  # type: ignore

        return defn.GetDataType() == SpecTypeId.Length
    except Exception:
        pass

    try:
        from Autodesk.Revit.DB import ParameterType as PT  # type: ignore

        return defn.ParameterType == PT.Length
    except Exception:
        return False


def _looks_like_legacy_mm_in_length(name, raw_value):
    """Detect mm written directly into a Length parameter (should be feet).

    Proper feet for these params are small (e.g. 3.9 ft for 1200mm).
    Legacy raw values are the mm number itself (e.g. 1200).
    The gap between max valid feet and min legacy mm is huge,
    so a simple range check is reliable.
    """
    limit_mm = _LEGACY_MM_LENGTH_PARAM_LIMITS.get(name)
    if not limit_mm:
        return False

    try:
        value = float(raw_value)
    except Exception:
        return False

    if value <= 0:
        return False

    max_valid_ft = limit_mm / 304.8
    return value > max_valid_ft and value <= limit_mm


def parse_ids_from_string(ids_string):
    result = []
    if not ids_string:
        return result

    for part in ids_string.split(";"):
        part = part.strip()
        if not part:
            continue
        try:
            result.append(int(part))
        except Exception:
            pass
    return result


def delete_elements_by_ids(ids_list):
    """Удаляет элементы по списку int id. Возвращает количество удалённых."""
    doc = get_doc()
    if not doc:
        return 0

    deleted = 0
    for int_id in ids_list:
        try:
            el_id = ElementId(int_id)
            el = doc.GetElement(el_id)
            if el:
                doc.Delete(el_id)
                deleted += 1
        except Exception:
            pass
    return deleted


def get_or_create_line_style(
    doc,
    style_name,
    color=None,
    weight=1,
    line_pattern_name=None,
    update_existing=False,
):
    """Возвращает GraphicsStyle для подкатегории style_name под OST_Lines.

    Создаёт подкатегорию если не существует (требует открытой транзакции).
    color — Autodesk.Revit.DB.Color, по умолчанию серый (140,140,140).
    line_pattern_name — имя LinePattern (например 'Center', 'Dash'), None = сплошная.
    update_existing — если True, обновляет цвет/толщину/паттерн существующего стиля.
    """
    if color is None:
        color = Color(140, 140, 140)

    lines_cat = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines)

    for sub in lines_cat.SubCategories:
        if sub.Name == style_name:
            if update_existing:
                sub.LineColor = color
                sub.SetLineWeight(weight, GraphicsStyleType.Projection)
                if line_pattern_name:
                    pattern = _find_line_pattern(doc, line_pattern_name)
                    if pattern:
                        sub.SetLinePatternId(pattern.Id, GraphicsStyleType.Projection)
            return sub.GetGraphicsStyle(GraphicsStyleType.Projection)

    new_subcat = doc.Settings.Categories.NewSubcategory(lines_cat, style_name)
    new_subcat.LineColor = color
    new_subcat.SetLineWeight(weight, GraphicsStyleType.Projection)

    if line_pattern_name:
        pattern = _find_line_pattern(doc, line_pattern_name)
        if pattern:
            new_subcat.SetLinePatternId(pattern.Id, GraphicsStyleType.Projection)

    return new_subcat.GetGraphicsStyle(GraphicsStyleType.Projection)


def line_style_exists(doc, style_name):
    """Проверяет, существует ли подкатегория линии с таким именем."""
    lines_cat = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines)
    for sub in lines_cat.SubCategories:
        if sub.Name == style_name:
            return True
    return False


def _find_line_pattern(doc, name):
    """Ищет LinePatternElement по имени (case-insensitive)."""
    collector = FilteredElementCollector(doc).OfClass(LinePatternElement)
    name_lower = name.lower()
    for lpe in collector:
        if lpe.Name.lower() == name_lower:
            return lpe
    return None


def get_line_style_id(doc, style_name):
    """Возвращает Id стиля линии по имени или None."""
    lines_cat = doc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines)
    for sub in lines_cat.SubCategories:
        if sub.Name == style_name:
            gs = sub.GetGraphicsStyle(GraphicsStyleType.Projection)
            if gs:
                return gs.Id
    return None


def load_reinforcement_zones(floor, default_version=1):
    """Читает JSON зон усиления из параметра перекрытия."""
    raw = get_string_param(floor, REINFORCEMENT_ZONES_PARAM)
    if not raw:
        return {"version": int(default_version), "zones": []}

    try:
        data = json.loads(raw)
    except Exception:
        raise ValueError(tr("invalid_reinf_zones_json"))

    if isinstance(data, list):
        return {"version": int(default_version), "zones": data}

    if isinstance(data, dict):
        zones = data.get("zones")
        if isinstance(zones, list):
            return {
                "version": int(data.get("version", default_version)),
                "zones": zones,
            }

    raise ValueError(tr("invalid_reinf_zones_schema"))


def save_reinforcement_zones(floor, data):
    """Сохраняет JSON зон усиления в параметр перекрытия."""
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return set_string_param(floor, REINFORCEMENT_ZONES_PARAM, raw)


def read_reinforcement_zone_ids(floor):
    """Собирает все element ids из зон усиления (верх/низ/стойки)."""
    data = load_reinforcement_zones(floor)
    zones = data.get("zones") or []

    ids = []
    for zone in zones:
        if not isinstance(zone, dict):
            continue
        for key in ("upper_ids", "lower_ids", "support_ids"):
            values = zone.get(key) or []
            for v in values:
                try:
                    ids.append(int(v))
                except Exception:
                    pass
    return ids


def cut_equal_1d(start, end, max_len, tol=1e-6):
    """Равномерная нарезка отрезка [start, end] на части <= max_len."""
    start = _require_finite_float(start, "start")
    end = _require_finite_float(end, "end")
    max_len = _require_positive_float(max_len, tr("spacing_positive"), "max_len")
    tol = _require_finite_float(tol, "tol")
    if end < start:
        raise ValueError(tr("range_min_exceeds_max"))

    total = end - start
    if total <= max_len + tol:
        return [(start, end)]

    n = int(math.ceil(total / max_len))
    step = total / n
    segs = []
    for i in range(n):
        a = start + step * i
        b = start + step * (i + 1) if i < n - 1 else end
        segs.append((a, b))
    return segs


def cut_at_positions_1d(start, end, max_len, positions, tol=1e-6, min_piece_ratio=0.25):
    """Нарезка [start, end] <= max_len с приоритетом стыков в positions.

    После нарезки: если крайние куски (первый/последний) короче
    min_piece_ratio * max_len, они перебалансируются с соседним куском:
    стык смещается в ближайшую к середине зоны допустимую position.
    """
    start = _require_finite_float(start, "start")
    end = _require_finite_float(end, "end")
    max_len = _require_positive_float(max_len, tr("spacing_positive"), "max_len")
    tol = _require_finite_float(tol, "tol")
    min_piece_ratio = _require_finite_float(min_piece_ratio, "min_piece_ratio")
    if end < start:
        raise ValueError(tr("range_min_exceeds_max"))
    if min_piece_ratio <= 0:
        raise ValueError(tr("spacing_positive"))

    if end - start <= max_len + tol:
        return [(start, end)]

    cands = sorted(p for p in positions if start + tol < p < end - tol)
    if not cands:
        return cut_equal_1d(start, end, max_len, tol=tol)

    segs = []
    cur = start
    while end - cur > max_len + tol:
        best = None
        for p in cands:
            if p <= cur + tol:
                continue
            if p - cur > max_len + tol:
                break
            best = p
        if best is None:
            segs.extend(cut_equal_1d(cur, end, max_len, tol=tol))
            return _rebalance_short_edges(segs, max_len, min_piece_ratio, tol, cands)
        segs.append((cur, best))
        cur = best

    segs.append((cur, end))
    return _rebalance_short_edges(segs, max_len, min_piece_ratio, tol, cands)


def _rebalance_short_edges(segs, max_len, min_piece_ratio, tol, positions):
    """Убирает слишком короткие крайние куски, сохраняя стыки в positions.

    Если крайний кусок < min_piece_ratio * max_len:
    - Если слияние с соседом ≤ max_len → объединить в один.
    - Иначе → найти в positions точку ближайшую к середине зоны,
      чтобы оба куска были ≤ max_len. Если такой нет — оставить как есть.
    """
    if len(segs) < 2:
        return segs

    min_piece = max_len * min_piece_ratio

    # Последний кусок слишком короткий
    last_len = segs[-1][1] - segs[-1][0]
    if last_len < min_piece - tol:
        combined_start = segs[-2][0]
        combined_end = segs[-1][1]
        segs = segs[:-2] + _split_zone(
            combined_start, combined_end, max_len, positions, tol
        )

    if len(segs) < 2:
        return segs

    # Первый кусок слишком короткий
    first_len = segs[0][1] - segs[0][0]
    if first_len < min_piece - tol:
        combined_start = segs[0][0]
        combined_end = segs[1][1]
        segs = (
            _split_zone(combined_start, combined_end, max_len, positions, tol)
            + segs[2:]
        )

    return segs


def _split_zone(zone_start, zone_end, max_len, positions, tol):
    """Разбивает зону [zone_start, zone_end] на 1 или 2 куска.

    - Если зона ≤ max_len → один кусок.
    - Иначе ищем лучшую позицию стыка из positions в зоне, чтобы:
      - оба куска ≤ max_len
      - стык как можно ближе к середине (максимально сбалансированно)
    - Если подходящей position нет → равномерная нарезка.
    """
    total = zone_end - zone_start
    if total <= max_len + tol:
        return [(zone_start, zone_end)]

    mid = (zone_start + zone_end) / 2.0
    best_pos = None
    best_dist = None
    for p in positions:
        if p <= zone_start + tol or p >= zone_end - tol:
            continue
        left = p - zone_start
        right = zone_end - p
        if left > max_len + tol or right > max_len + tol:
            continue
        dist = abs(p - mid)
        if best_pos is None or dist < best_dist:
            best_pos = p
            best_dist = dist

    if best_pos is not None:
        return [(zone_start, best_pos), (best_pos, zone_end)]

    return cut_equal_1d(zone_start, zone_end, max_len, tol=tol)


def split_orthogonal_segments(segs, max_len, tol=1e-6, positions=None):
    """Нарезка H/V сегментов на части <= max_len.

    Если передан positions, стыки пытаются попадать в эти позиции.
    Для горизонтальных сегментов positions интерпретируется как X-позиции,
    для вертикальных - как Y-позиции.
    """
    result = []
    positions = positions or []

    for x1, y1, x2, y2 in segs:
        if abs(y1 - y2) < tol:
            s, e = min(x1, x2), max(x1, x2)
            pieces = (
                cut_at_positions_1d(s, e, max_len, positions, tol=tol)
                if positions
                else cut_equal_1d(s, e, max_len, tol=tol)
            )
            for a, b in pieces:
                result.append((a, y1, b, y2))
        elif abs(x1 - x2) < tol:
            s, e = min(y1, y2), max(y1, y2)
            pieces = (
                cut_at_positions_1d(s, e, max_len, positions, tol=tol)
                if positions
                else cut_equal_1d(s, e, max_len, tol=tol)
            )
            for a, b in pieces:
                result.append((x1, a, x2, b))
        else:
            result.append((x1, y1, x2, y2))

    return result


def compute_stagger_positions(main_keys, lower_positions):
    """Вычисляет наборы позиций для шахматного порядка стыков стрингеров.

    Returns:
        dict с ключами:
        - lp_even, lp_odd: чётные/нечётные позиции нижних (для нарезки верхних)
        - mk_mids_even, mk_mids_odd: чётные/нечётные серединные пролёты (для нарезки нижних)
        - stagger_odd_upper: set — позиции верхних, режущихся по lp_odd
        - stagger_odd_lower: set — позиции нижних, режущихся по mk_mids_odd
    """

    def _rc(v):
        return round(v, 6)

    sorted_lp = sorted(lower_positions)
    sorted_mk = sorted(main_keys)

    if len(sorted_lp) >= 2:
        lp_even = sorted_lp[::2]
        lp_odd = sorted_lp[1::2]
    else:
        lp_even = list(sorted_lp)
        lp_odd = list(sorted_lp)

    mk_mids = [
        (sorted_mk[i] + sorted_mk[i + 1]) / 2.0 for i in range(len(sorted_mk) - 1)
    ]
    if len(mk_mids) >= 2:
        mk_mids_even = mk_mids[::2]
        mk_mids_odd = mk_mids[1::2]
    else:
        mk_mids_even = list(mk_mids)
        mk_mids_odd = list(mk_mids)

    stagger_odd_upper = set(_rc(p) for p in sorted_mk[1::2])
    stagger_odd_lower = set(_rc(p) for p in sorted_lp[1::2])

    return {
        "lp_even": lp_even,
        "lp_odd": lp_odd,
        "mk_mids_even": mk_mids_even,
        "mk_mids_odd": mk_mids_odd,
        "stagger_odd_upper": stagger_odd_upper,
        "stagger_odd_lower": stagger_odd_lower,
    }


def drop_near_parallel(contour_segs, grid_segs, tol, seg_tol=1e-6, protect_segs=None):
    """Отсеивает контурные сегменты, параллельные и ближе tol к осевым.

    Сравнение по поперечной координате: X для вертикальных, Y для горизонтальных.
    Если осевой и контурный перекрываются по длине — контурный удаляется.

    Если передан protect_segs (например, верхние hole-контурные), нижний
    контурный НЕ удаляется, если с ним пересекается хотя бы один protect-сегмент
    (верхнему нужна опора снизу).

    Returns:
        (kept_segs, dropped_count)
    """
    if not contour_segs or not grid_segs:
        return list(contour_segs), 0

    def _key(seg):
        x1, y1, x2, y2 = seg
        if abs(y1 - y2) < seg_tol:
            return True, (y1 + y2) / 2.0, min(x1, x2), max(x1, x2)
        if abs(x1 - x2) < seg_tol:
            return False, (x1 + x2) / 2.0, min(y1, y2), max(y1, y2)
        return None, 0, 0, 0

    def _segs_cross(seg_a, seg_b):
        """True если два ортогональных сегмента пересекаются."""
        a_h, a_pos, a_min, a_max = _key(seg_a)
        b_h, b_pos, b_min, b_max = _key(seg_b)
        if a_h is None or b_h is None or a_h == b_h:
            return False
        # a — горизонтальный (Y=a_pos, X∈[a_min,a_max])
        # b — вертикальный   (X=b_pos, Y∈[b_min,b_max])
        h_seg, h_pos, h_min, h_max = (
            (a_pos, a_min, a_max, None) if a_h else (b_pos, b_min, b_max, None)
        )
        v_seg, v_pos, v_min, v_max = (
            (b_pos, b_min, b_max, None) if a_h else (a_pos, a_min, a_max, None)
        )
        # Переупаковка
        if a_h:
            hy, hx_min, hx_max = a_pos, a_min, a_max
            vx, vy_min, vy_max = b_pos, b_min, b_max
        else:
            hy, hx_min, hx_max = b_pos, b_min, b_max
            vx, vy_min, vy_max = a_pos, a_min, a_max
        return hx_min - tol <= vx <= hx_max + tol and vy_min - tol <= hy <= vy_max + tol

    grid_h, grid_v = [], []
    for seg in grid_segs:
        is_h, pos, smin, smax = _key(seg)
        if is_h is True:
            grid_h.append((pos, smin, smax))
        elif is_h is False:
            grid_v.append((pos, smin, smax))

    kept, dropped = [], 0
    for seg in contour_segs:
        is_h, pos, smin, smax = _key(seg)
        pool = grid_h if is_h is True else grid_v if is_h is False else []
        dominated = False
        for g_pos, g_smin, g_smax in pool:
            if abs(pos - g_pos) < tol:
                if g_smin < smax + seg_tol and g_smax > smin - seg_tol:
                    dominated = True
                    break
        if dominated and protect_segs:
            for p_seg in protect_segs:
                if _segs_cross(seg, p_seg):
                    dominated = False
                    break
        if dominated:
            dropped += 1
        else:
            kept.append(seg)
    return kept, dropped


def build_support_nodes(
    lower_segs, max_spacing, support_half=0.0, tol=1e-6, grid_positions=None
):
    """Узлы стоек вдоль нижних лонжеронов с дедупликацией.

    Считает каждый сегмент стрингера отдельно:
    - обязательные: начало/конец сегмента;
    - на общих стыках соседних сегментов стойка ставится в точку стыка
      (одна на два стрингера);
    - промежуточные: стараемся ставить на grid_positions (если переданы),
      с учётом max_spacing.

    В шахматной раскладке всего 2 варианта нарезки — начало/конец
    соседних стрингеров сдвинуты на 1 пролёт, но промежуточные
    стойки выравниваются в ряд по одним и тем же grid_positions.
    """
    max_spacing = _require_positive_float(
        max_spacing, tr("spacing_positive"), "max_spacing"
    )
    support_half = _require_finite_float(support_half, "support_half")
    tol = _require_finite_float(tol, "tol")

    def _rc(v):
        return round(v, 6)

    def _anchor_towards_inside(along, other, shared_endpoint):
        """Смещает край в сторону тела сегмента, если это не стык."""
        if shared_endpoint or support_half <= tol:
            return along
        delta = other - along
        if abs(delta) <= tol:
            return along
        shift = min(support_half, abs(delta))
        return along + (shift if delta > 0 else -shift)

    # --- Определяем ось нижних стрингеров ---
    seg_axis = None
    for x1, y1, x2, y2 in lower_segs:
        dxa = abs(x2 - x1)
        dya = abs(y2 - y1)
        if dxa < tol and dya < tol:
            continue
        seg_axis = "X" if dxa >= dya else "Y"
        break
    if seg_axis is None:
        return []

    # --- Считаем кратность концов (стык = общая точка >= 2 сегментов) ---
    endpoint_count = {}
    for x1, y1, x2, y2 in lower_segs:
        p0 = (_rc(x1), _rc(y1))
        p1 = (_rc(x2), _rc(y2))
        endpoint_count[p0] = endpoint_count.get(p0, 0) + 1
        endpoint_count[p1] = endpoint_count.get(p1, 0) + 1

    # --- Расставляем стойки по каждому сегменту ---
    support_set = set()
    for x1, y1, x2, y2 in lower_segs:
        if seg_axis == "X":
            along0 = _rc(x1)
            along1 = _rc(x2)
            perp = _rc((y1 + y2) / 2.0)
        else:
            along0 = _rc(y1)
            along1 = _rc(y2)
            perp = _rc((x1 + x2) / 2.0)

        p0 = (_rc(x1), _rc(y1))
        p1 = (_rc(x2), _rc(y2))

        # Обязательные края сегмента:
        # - в стыке оставляем точное положение,
        # - на свободном конце даём отступ support_half внутрь сегмента.
        s0 = _anchor_towards_inside(
            along0,
            along1,
            endpoint_count.get(p0, 1) > 1,
        )
        s1 = _anchor_towards_inside(
            along1,
            along0,
            endpoint_count.get(p1, 1) > 1,
        )

        span_start = min(s0, s1)
        span_end = max(s0, s1)
        if span_end - span_start < tol:
            val = _rc((s0 + s1) / 2.0)
            if seg_axis == "X":
                support_set.add((val, perp))
            else:
                support_set.add((perp, val))
            continue

        candidates = []
        if grid_positions is not None:
            for gp in grid_positions:
                if gp <= span_start + tol or gp >= span_end - tol:
                    continue
                candidates.append(gp)

        selected = _select_line_supports(
            span_start,
            span_end,
            candidates,
            max_spacing,
            tol,
        )
        for val in selected:
            if seg_axis == "X":
                support_set.add((_rc(val), perp))
            else:
                support_set.add((perp, _rc(val)))

    return sorted(support_set)


def _select_line_supports(start, end, grid_candidates, min_spacing, tol):
    """Расставляет стойки вдоль линии [start..end].

    Начало и конец — обязательны. Промежуточные — на позициях из
    grid_candidates (линии сетки), не ближе min_spacing друг к другу
    и к началу/концу.

    Если grid_candidates пуст или не покрывает длинный пролёт —
    добавляет равномерные промежуточные (страховка).
    """
    start = _require_finite_float(start, "start")
    end = _require_finite_float(end, "end")
    min_spacing = _require_positive_float(
        min_spacing, tr("spacing_positive"), "min_spacing"
    )
    tol = _require_finite_float(tol, "tol")
    if end < start:
        raise ValueError(tr("range_min_exceeds_max"))

    length = end - start
    if length < tol:
        return [start]

    result = [start, end]

    if length <= min_spacing + tol:
        return result

    # Фильтр: далеко от start и end
    valid = sorted(
        g
        for g in grid_candidates
        if g > start + min_spacing - tol and g < end - min_spacing + tol
    )

    # Жадный отбор: не ближе min_spacing друг к другу
    last = start
    for g in valid:
        if g - last < min_spacing - tol:
            continue
        if end - g < min_spacing - tol:
            break
        result.append(g)
        last = g

    # Страховка: если сетка не закрывает длинный пролёт, добиваем равномерно,
    # но не нарушаем минимальный шаг.
    result.sort()
    extra = []
    if min_spacing > tol:
        for i in range(len(result) - 1):
            span = result[i + 1] - result[i]
            if span <= 2.0 * min_spacing + tol:
                continue
            n_add = int(math.floor(span / min_spacing)) - 1
            if n_add <= 0:
                continue
            step = span / float(n_add + 1)
            for j in range(1, n_add + 1):
                extra.append(result[i] + step * j)
    result.extend(extra)
    result.sort()
    return result
