# -*- coding: utf-8 -*-

from Autodesk.Revit.DB import (  # type: ignore
    XYZ,
    Color,
    CurveElement,
    ElementId,
    Family,
    FilteredElementCollector,
    Line,
)
from floor_common import (
    build_positions,
    get_double_param,
    get_id_value,
    get_line_style_id,
    get_or_create_line_style,
    get_string_param,
    parse_ids_from_string,
    set_string_param,
)
from rf_config import (  # type: ignore
    CLIPPER_SCALE,
    DEFAULT_STRINGER_CLEARANCE_MM,
    GRID_MARKER_ARM_FT,
    GRID_MARKER_RING_HALF_FT,
    MIN_SEGMENT_LENGTH_FT,
    MM_PER_FOOT,
)
from rf_param_schema import RFFamilies, RFParams as P  # type: ignore
from revit_context import get_doc  # type: ignore
from pyrevit import revit  # type: ignore

GRID_LINE_STYLE_NAME = "RF_Grid"
GRID_COLOR = Color(100, 149, 237)  # васильковый синий
GRID_LINE_PATTERN = "Center"

BASE_MARKER_STYLE_NAME = "RF_Base"
BASE_MARKER_COLOR = Color(255, 0, 120)

CONTOUR_STYLE_NAME = "RF_Contour"
CONTOUR_COLOR = Color(0, 255, 0)

NEAR_COLUMN_STYLE_NAME = "RF_GridColumn"
NEAR_COLUMN_COLOR = Color(255, 80, 80)  # красный — внимание

NON_VIABLE_STYLE_NAME = "RF_NonViable"
NON_VIABLE_COLOR = Color(255, 50, 0)  # ярко-красный — немонтируемые ячейки

# Compatibility aliases kept for non-Revit tests and legacy imports.
_DEFAULT_COL_CLEARANCE_MM = DEFAULT_STRINGER_CLEARANCE_MM
_MIN_SEG_LEN = MIN_SEGMENT_LENGTH_FT
_MARKER_ARM = GRID_MARKER_ARM_FT
_MARKER_RING_HALF = GRID_MARKER_RING_HALF_FT
_INTERNAL_TO_MM = MM_PER_FOOT
_SCALE = CLIPPER_SCALE

def _get_stringer_clearance_mm():
    """Читает макс. ширину профиля стрингера (мм) для near-edge подсветки."""
    doc = get_doc()
    if not doc:
        return DEFAULT_STRINGER_CLEARANCE_MM

    clearance = 0.0
    for fam in FilteredElementCollector(doc).OfClass(Family):
        if fam.Name == RFFamilies.STRINGER:
            for sid in fam.GetFamilySymbolIds():
                sym = doc.GetElement(sid)
                if sym:
                    pw = get_double_param(sym, P.PROFILE_WIDTH)
                    if pw:
                        pw_mm = pw * MM_PER_FOOT
                        if pw_mm > clearance:
                            clearance = pw_mm
            break
    return clearance if clearance > 0 else DEFAULT_STRINGER_CLEARANCE_MM


# ---------------------------------------------------------------------------
#  Clipper2: клиппинг линий по контуру
# ---------------------------------------------------------------------------


def _internal_to_clipper(val):
    """internal (feet) → clipper int64 units."""
    return int(round(val * MM_PER_FOOT * CLIPPER_SCALE))


def _clipper_to_internal(val):
    """clipper int64 units → internal (feet)."""
    return float(val) / CLIPPER_SCALE / MM_PER_FOOT


def _build_clip_paths(floor):
    """Builds clip-paths from exact zone and returns (clip_paths, hole_edge_coords).

    hole_edge_coords: list of (min_x, min_y, max_x, max_y) in internal units per hole,
    or empty list if no holes.
    """
    doc = get_doc()
    if not doc:
        return None, []

    try:
        from floor_exact import (
            Difference,
            FillRule,
            clipper_to_mm,
            get_exact_zone_for_floor,
            mm_to_internal,
        )
    except Exception:
        return None, []

    try:
        zone = get_exact_zone_for_floor(doc, floor)
    except Exception:
        return None, []

    outer = zone.get("outer_paths")
    holes = zone.get("hole_paths")
    if not outer or outer.Count == 0:
        return None, []

    hole_edge_coords = []
    if holes and holes.Count > 0:
        for hp in holes:
            hxs = [mm_to_internal(clipper_to_mm(pt.X)) for pt in hp]
            hys = [mm_to_internal(clipper_to_mm(pt.Y)) for pt in hp]
            if hxs and hys:
                hole_edge_coords.append((min(hxs), min(hys), max(hxs), max(hys)))
        clip = Difference(outer, holes, FillRule.NonZero)
    else:
        clip = outer

    return clip, hole_edge_coords


def _clip_line_segments(x0, y0, x1, y1, clip_paths):
    """Клиппирует отрезок (x0,y0)-(x1,y1) в internal-координатах Clipper2-контуром.

    Возвращает список кортежей ((ax,ay), (bx,by)) в internal units.
    """
    from floor_exact import Clipper64, ClipType, FillRule, Path64, Paths64, Point64

    line_path = Path64()
    line_path.Add(Point64(_internal_to_clipper(x0), _internal_to_clipper(y0)))
    line_path.Add(Point64(_internal_to_clipper(x1), _internal_to_clipper(y1)))

    open_subj = Paths64()
    open_subj.Add(line_path)

    clipper = Clipper64()
    clipper.AddOpenSubject(open_subj)
    clipper.AddClip(clip_paths)

    sol_closed = Paths64()
    sol_open = Paths64()
    clipper.Execute(ClipType.Intersection, FillRule.NonZero, sol_closed, sol_open)

    segments = []
    for path in sol_open:
        if path.Count < 2:
            continue
        p0 = path[0]
        p1 = path[path.Count - 1]
        ax = _clipper_to_internal(p0.X)
        ay = _clipper_to_internal(p0.Y)
        bx = _clipper_to_internal(p1.X)
        by = _clipper_to_internal(p1.Y)
        # Фильтр слишком коротких
        length = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
        if length >= MIN_SEGMENT_LENGTH_FT:
            segments.append(((ax, ay), (bx, by)))

    return segments


def get_bbox_xy(el, active_view):
    bbox = el.get_BoundingBox(active_view)
    if not bbox:
        bbox = el.get_BoundingBox(None)
    if not bbox:
        return None

    return bbox.Min.X, bbox.Min.Y, bbox.Max.X, bbox.Max.Y, bbox.Min.Z, bbox.Max.Z


def _collect_styled_curve_ids(view, style_id):
    """Собирает Id всех DetailCurve на виде с заданным стилем линии."""
    doc = get_doc()
    if not doc:
        return []

    ids = []
    if not style_id:
        return ids

    collector = FilteredElementCollector(doc, view.Id).OfClass(CurveElement)
    for curve_el in collector:
        try:
            if not curve_el.ViewSpecific:
                continue
            ls = curve_el.LineStyle
            if ls and ls.Id == style_id:
                ids.append(get_id_value(curve_el))
        except Exception:
            pass

    return ids


def _curve_inside_xy_box(curve_el, min_x, min_y, max_x, max_y):
    """Check whether a detail curve lies inside an XY box."""
    try:
        curve = getattr(curve_el, "GeometryCurve", None)
        if curve is None:
            loc = getattr(curve_el, "Location", None)
            curve = getattr(loc, "Curve", None) if loc is not None else None
        if curve is None:
            return False

        p0 = curve.GetEndPoint(0)
        p1 = curve.GetEndPoint(1)
        xs = (p0.X, p1.X)
        ys = (p0.Y, p1.Y)
        return (
            min(xs) >= min_x
            and max(xs) <= max_x
            and min(ys) >= min_y
            and max(ys) <= max_y
        )
    except Exception:
        return False


def _collect_marker_ids_near_points(view, points, radius):
    """Collect stale base-marker curve ids near candidate base points."""
    doc = get_doc()
    if not doc or not points:
        return []

    style_id = get_line_style_id(doc, BASE_MARKER_STYLE_NAME)
    if not style_id:
        return []

    ids = []
    seen_ids = set()
    collector = FilteredElementCollector(doc, view.Id).OfClass(CurveElement)
    for curve_el in collector:
        try:
            if not curve_el.ViewSpecific:
                continue
            ls = curve_el.LineStyle
            if not ls or ls.Id != style_id:
                continue
        except Exception:
            continue

        for x_val, y_val in points:
            if _curve_inside_xy_box(
                curve_el,
                x_val - radius,
                y_val - radius,
                x_val + radius,
                y_val + radius,
            ):
                int_id = get_id_value(curve_el)
                if int_id not in seen_ids:
                    seen_ids.add(int_id)
                    ids.append(int_id)
                break

    return ids


def _collect_owned_grid_ids(floor):
    """Возвращает уникальные ID элементов сетки, принадлежащих выбранному полу.

    Важно: redraw/cleanup не должны удалять все RF-линии на виде по стилю.
    Иначе перерисовка одной зоны может снести сетку соседней зоны в том же плане.
    """
    ids_to_delete = []
    seen_ids = set()

    for param_name in (P.GRID_LINES_ID, P.BASE_MARKER_ID):
        ids = parse_ids_from_string(get_string_param(floor, param_name))
        for int_id in ids:
            if int_id in seen_ids:
                continue
            seen_ids.add(int_id)
            ids_to_delete.append(int_id)

    return ids_to_delete


def _collect_contour_curves(floor):
    """Собрать клонированные кривые контура ДО транзакции.

    Возвращает (old_ids, curves). Кривые клонированы, чтобы не зависеть
    от состояния документа внутри транзакции.
    """
    old_contour_ids = parse_ids_from_string(
        get_string_param(floor, P.CONTOUR_LINES_ID)
    )
    if not old_contour_ids:
        return [], []

    curves = []
    doc = get_doc()
    if not doc:
        return old_contour_ids, curves

    for int_id in old_contour_ids:
        try:
            el = doc.GetElement(ElementId(int_id))
            if el and hasattr(el, "GeometryCurve"):
                curves.append(el.GeometryCurve.Clone())
        except Exception:
            pass

    return old_contour_ids, curves


def _recreate_contour_on_top(floor, view, old_contour_ids, curves, update_style=False):
    """Пересоздать контурные линии (удалить → создать), чтобы они были поверх сетки.

    old_contour_ids и curves должны быть собраны _collect_contour_curves()
    ДО начала транзакции, чтобы избежать ошибки "referenced object is not valid".
    """
    if not curves:
        return 0

    doc = get_doc()
    if not doc:
        return 0

    contour_style = get_or_create_line_style(
        doc,
        CONTOUR_STYLE_NAME,
        color=CONTOUR_COLOR,
        weight=5,
        update_existing=update_style,
    )

    # Удалить старые
    for int_id in old_contour_ids:
        try:
            doc.Delete(ElementId(int_id))
        except Exception:
            pass

    # Создать заново (последними → поверх сетки)
    new_ids = []
    for crv in curves:
        try:
            dc = doc.Create.NewDetailCurve(view, crv)
            dc.LineStyle = contour_style
            new_ids.append(str(get_id_value(dc)))
        except Exception:
            pass

    if new_ids:
        set_string_param(floor, P.CONTOUR_LINES_ID, ";".join(new_ids))

    return len(new_ids)


def redraw_grid_for_floor(
    floor,
    view,
    transaction_name,
    update_style=False,
    non_viable_cells=None,
    cleanup_marker_points=None,
):
    doc = get_doc()
    if not doc:
        raise Exception("Не удалось получить активный документ Revit.")

    step_x = get_double_param(floor, P.STEP_X)
    step_y = get_double_param(floor, P.STEP_Y)
    base_x_raw = get_double_param(floor, P.BASE_X)
    base_y_raw = get_double_param(floor, P.BASE_Y)
    shift_x = get_double_param(floor, P.OFFSET_X)
    shift_y = get_double_param(floor, P.OFFSET_Y)

    missing = []
    if step_x is None:
        missing.append(P.STEP_X)
    if step_y is None:
        missing.append(P.STEP_Y)
    if base_x_raw is None:
        missing.append(P.BASE_X)
    if base_y_raw is None:
        missing.append(P.BASE_Y)
    if shift_x is None:
        missing.append(P.OFFSET_X)
    if shift_y is None:
        missing.append(P.OFFSET_Y)

    if missing:
        raise Exception(
            "Не удалось прочитать параметры:\n- {}".format("\n- ".join(missing))
        )

    # type narrowing for Pylance (all None-checks above guarantee non-None here)
    assert step_x is not None and step_y is not None
    assert base_x_raw is not None and base_y_raw is not None
    assert shift_x is not None and shift_y is not None

    if step_x <= 0 or step_y <= 0:
        raise Exception("Шаг сетки должен быть больше нуля.")

    base_x = base_x_raw + shift_x
    base_y = base_y_raw + shift_y

    bbox_data = get_bbox_xy(floor, view)
    if not bbox_data:
        raise Exception("Не удалось определить габариты перекрытия.")

    min_x, min_y, max_x, max_y, z0 = bbox_data[:5]

    pad = min(step_x, step_y) * 0.2
    min_x -= pad
    min_y -= pad
    max_x += pad
    max_y += pad

    x_positions = build_positions(
        min_x, max_x, base_x, step_x, end_padding_steps=1.0, end_tolerance=0.0
    )
    y_positions = build_positions(
        min_y, max_y, base_y, step_y, end_padding_steps=1.0, end_tolerance=0.0
    )

    if not x_positions and not y_positions:
        raise Exception("Не удалось построить позиции линий сетки.")

    # Удаляем только элементы, явно привязанные к выбранному полу через RF_*_ID.
    # Broad fallback по стилю намеренно не используем, чтобы не затрагивать соседние зоны.
    ids_to_delete = _collect_owned_grid_ids(floor)
    if cleanup_marker_points:
        marker_cleanup_ids = _collect_marker_ids_near_points(
            view,
            cleanup_marker_points,
            GRID_MARKER_ARM_FT * 3.0,
        )
        if marker_cleanup_ids:
            seen_ids = set(ids_to_delete)
            for int_id in marker_cleanup_ids:
                if int_id not in seen_ids:
                    seen_ids.add(int_id)
                    ids_to_delete.append(int_id)

    # Читаем всю геометрию ДО транзакции — внутри транзакции ссылки
    # на геометрию элементов могут стать невалидными ("referenced object").
    clip_paths, hole_edge_coords = _build_clip_paths(floor)
    contour_old_ids, contour_curves = _collect_contour_curves(floor)

    deleted_count = 0
    created_ids = []

    with revit.Transaction(transaction_name):
        grid_style = get_or_create_line_style(
            doc,
            GRID_LINE_STYLE_NAME,
            GRID_COLOR,
            line_pattern_name=GRID_LINE_PATTERN,
            update_existing=update_style,
        )

        for int_id in ids_to_delete:
            try:
                el_id = ElementId(int_id)
                old_el = doc.GetElement(el_id)
                if old_el:
                    doc.Delete(el_id)
                    deleted_count += 1
            except Exception:
                pass

        # Стиль для линий у колонн (если есть колонны)
        near_col_style = None
        if hole_edge_coords:
            near_col_style = get_or_create_line_style(
                doc,
                NEAR_COLUMN_STYLE_NAME,
                NEAR_COLUMN_COLOR,
                line_pattern_name=GRID_LINE_PATTERN,
                update_existing=update_style,
            )

        # Проверка: линия сетки рядом с ребром колонны?
        _col_clearance = _get_stringer_clearance_mm() / MM_PER_FOOT  # мм → feet

        def _is_near_column_x(x_val):
            for hmin_x, _hmin_y, hmax_x, _hmax_y in hole_edge_coords:
                if (
                    abs(x_val - hmin_x) < _col_clearance
                    or abs(x_val - hmax_x) < _col_clearance
                ):
                    return True
            return False

        def _is_near_column_y(y_val):
            for _hmin_x, hmin_y, _hmax_x, hmax_y in hole_edge_coords:
                if (
                    abs(y_val - hmin_y) < _col_clearance
                    or abs(y_val - hmax_y) < _col_clearance
                ):
                    return True
            return False

        near_col_count = 0

        for x in x_positions:
            is_near = near_col_style and _is_near_column_x(x)
            if is_near:
                near_col_count += 1
            if clip_paths:
                segs = _clip_line_segments(x, min_y, x, max_y, clip_paths)
            else:
                segs = [((x, min_y), (x, max_y))]
            for (ax, ay), (bx, by) in segs:
                line = Line.CreateBound(XYZ(ax, ay, z0), XYZ(bx, by, z0))
                dc = doc.Create.NewDetailCurve(view, line)
                dc.LineStyle = near_col_style if is_near else grid_style
                created_ids.append(str(get_id_value(dc)))

        for y in y_positions:
            is_near = near_col_style and _is_near_column_y(y)
            if is_near:
                near_col_count += 1
            if clip_paths:
                segs = _clip_line_segments(min_x, y, max_x, y, clip_paths)
            else:
                segs = [((min_x, y), (max_x, y))]
            for (ax, ay), (bx, by) in segs:
                line = Line.CreateBound(XYZ(ax, ay, z0), XYZ(bx, by, z0))
                dc = doc.Create.NewDetailCurve(view, line)
                dc.LineStyle = near_col_style if is_near else grid_style
                created_ids.append(str(get_id_value(dc)))

        # Крестик точки начала раскладки (только если база в зоне bbox)
        marker_ids = []
        marker_pad = GRID_MARKER_ARM_FT * 2
        if (
            min_x - marker_pad <= base_x <= max_x + marker_pad
            and min_y - marker_pad <= base_y <= max_y + marker_pad
        ):
            marker_style = get_or_create_line_style(
                doc,
                BASE_MARKER_STYLE_NAME,
                BASE_MARKER_COLOR,
                weight=4,
                update_existing=update_style,
            )

            # Контрастная, но компактная мишень: + и квадратная рамка.
            m_line_h = Line.CreateBound(
                XYZ(base_x - GRID_MARKER_ARM_FT, base_y, z0),
                XYZ(base_x + GRID_MARKER_ARM_FT, base_y, z0),
            )
            dc_h = doc.Create.NewDetailCurve(view, m_line_h)
            dc_h.LineStyle = marker_style
            marker_ids.append(str(get_id_value(dc_h)))

            m_line_v = Line.CreateBound(
                XYZ(base_x, base_y - GRID_MARKER_ARM_FT, z0),
                XYZ(base_x, base_y + GRID_MARKER_ARM_FT, z0),
            )
            dc_v = doc.Create.NewDetailCurve(view, m_line_v)
            dc_v.LineStyle = marker_style
            marker_ids.append(str(get_id_value(dc_v)))

            rx0 = base_x - GRID_MARKER_RING_HALF_FT
            rx1 = base_x + GRID_MARKER_RING_HALF_FT
            ry0 = base_y - GRID_MARKER_RING_HALF_FT
            ry1 = base_y + GRID_MARKER_RING_HALF_FT
            ring_lines = [
                Line.CreateBound(XYZ(rx0, ry0, z0), XYZ(rx1, ry0, z0)),
                Line.CreateBound(XYZ(rx1, ry0, z0), XYZ(rx1, ry1, z0)),
                Line.CreateBound(XYZ(rx1, ry1, z0), XYZ(rx0, ry1, z0)),
                Line.CreateBound(XYZ(rx0, ry1, z0), XYZ(rx0, ry0, z0)),
            ]
            for ring in ring_lines:
                dc_r = doc.Create.NewDetailCurve(view, ring)
                dc_r.LineStyle = marker_style
                marker_ids.append(str(get_id_value(dc_r)))

        # X-кресты на немонтируемых ячейках
        nv_count = 0
        if non_viable_cells:
            nv_style = get_or_create_line_style(
                doc,
                NON_VIABLE_STYLE_NAME,
                NON_VIABLE_COLOR,
                weight=3,
                update_existing=update_style,
            )
            for cx0, cy0, cx1, cy1 in non_viable_cells:
                try:
                    d1 = Line.CreateBound(XYZ(cx0, cy0, z0), XYZ(cx1, cy1, z0))
                    dc1 = doc.Create.NewDetailCurve(view, d1)
                    dc1.LineStyle = nv_style
                    created_ids.append(str(get_id_value(dc1)))
                    d2 = Line.CreateBound(XYZ(cx0, cy1, z0), XYZ(cx1, cy0, z0))
                    dc2 = doc.Create.NewDetailCurve(view, d2)
                    dc2.LineStyle = nv_style
                    created_ids.append(str(get_id_value(dc2)))
                    nv_count += 1
                except Exception:
                    pass

        ids_string = ";".join(created_ids)
        ok = set_string_param(floor, P.GRID_LINES_ID, ids_string)
        if not ok:
            raise Exception("Не удалось записать {}".format(P.GRID_LINES_ID))

        if marker_ids:
            marker_ids_string = ";".join(marker_ids)
            ok_marker = set_string_param(floor, P.BASE_MARKER_ID, marker_ids_string)
            if not ok_marker:
                raise Exception("Не удалось записать {}".format(P.BASE_MARKER_ID))
        else:
            ok_marker = set_string_param(floor, P.BASE_MARKER_ID, "")
            if not ok_marker:
                raise Exception("Не удалось очистить {}".format(P.BASE_MARKER_ID))

        # Пересоздать контурные линии последними — чтобы они были поверх сетки
        contour_recreated = _recreate_contour_on_top(
            floor, view, contour_old_ids, contour_curves, update_style
        )

    return {
        "deleted_count": deleted_count,
        "created_count": len(created_ids),
        "near_col_count": near_col_count,
        "non_viable_drawn": nv_count,
        "marker_count": len(marker_ids),
        "contour_recreated": contour_recreated,
        "step_x": step_x,
        "step_y": step_y,
        "shift_x": shift_x,
        "shift_y": shift_y,
        "base_x": base_x,
        "base_y": base_y,
    }
