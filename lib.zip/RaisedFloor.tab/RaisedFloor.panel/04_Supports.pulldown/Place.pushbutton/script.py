# -*- coding: utf-8 -*-
"""07 Стойки — расстановка по размещённым нижним лонжеронам.

Логика:
  1. На каждом конце нижнего лонжерона — обязательная стойка.
  2. Промежуточные стойки равномерно с макс.шагом (по умолчанию 600 мм).
  3. Минимум 2 стойки на каждый лонжерон (концы).
  4. Совпадающие узлы (перекрёстки) дедуплицируются.
Сохраняет ID стоек в RF_Supports_ID.
"""

import math

from Autodesk.Revit.DB import (  # type: ignore
    XYZ,
    ElementId,
    ElementTransformUtils,
    Family,
    FilteredElementCollector,
    Line,
    StorageType,
    ViewPlan,
)
from Autodesk.Revit.DB.Structure import StructuralType  # type: ignore
from Autodesk.Revit.Exceptions import OperationCanceledException  # type: ignore
from Autodesk.Revit.UI.Selection import ObjectType  # type: ignore
from floor_common import (  # type: ignore
    FloorOrPartSelectionFilter,
    build_support_nodes,
    get_double_param,
    get_source_floor,
    get_string_param,
    parse_ids_from_string,
    set_string_param,
)
from floor_exact import (  # type: ignore
    internal_to_mm,
    mm_to_internal,
)
from floor_grid import get_bbox_xy  # type: ignore
from floor_i18n import tr  # type: ignore
from pyrevit import forms, revit  # type: ignore
from rf_config import DEFAULT_SUPPORT_SPACING_MM, GEOM_TOL  # type: ignore
from rf_param_schema import RFFamilies, RFParams as P  # type: ignore
from revit_context import get_active_view, get_doc, get_uidoc  # type: ignore

doc = None
uidoc = None
view = None

TITLE = tr("title_supports")
FAMILY_SUPPORT = RFFamilies.SUPPORT
COORD_TOL = GEOM_TOL


class _Cancel(Exception):
    pass


def _rc(v):
    return round(v, 6)


def _get_family_symbols(family_name):
    collector = FilteredElementCollector(doc).OfClass(Family)
    for fam in collector:
        if fam.Name == family_name:
            result = []
            for sid in fam.GetFamilySymbolIds():
                sym = doc.GetElement(sid)
                if sym:
                    result.append(sym)
            return result
    return []


def _set_param(inst, name, value):
    p = inst.LookupParameter(name)
    if not p or p.IsReadOnly:
        return
    if p.StorageType == StorageType.Integer:
        p.Set(int(value))
    elif p.StorageType == StorageType.Double:
        p.Set(float(value))
    elif p.StorageType == StorageType.String:
        p.Set(str(value))


def _get_tile_thickness_fallback():
    """Возвращает толщину плитки (ft) из семейства RF_Tile как fallback."""
    thickness = 0.0
    for sym in _get_family_symbols(RFFamilies.TILE):
        t = get_double_param(sym, P.THICKNESS) or 0.0
        if t > thickness:
            thickness = t
    return thickness


def _read_grid_lines(floor_el):
    """Читает DetailCurves сетки → v_keys, h_keys (отсортированные координаты)."""
    ids = parse_ids_from_string(get_string_param(floor_el, P.GRID_LINES_ID))
    v_set = set()
    h_set = set()
    for int_id in ids:
        el = doc.GetElement(ElementId(int_id))
        if el is None:
            continue
        geom = getattr(el, "GeometryCurve", None)
        if geom is None:
            continue
        p0 = geom.GetEndPoint(0)
        p1 = geom.GetEndPoint(1)
        dx = abs(p1.X - p0.X)
        dy = abs(p1.Y - p0.Y)
        if dx < COORD_TOL and dy > COORD_TOL:
            v_set.add(_rc(p0.X))
        elif dy < COORD_TOL and dx > COORD_TOL:
            h_set.add(_rc(p0.Y))
    return sorted(v_set), sorted(h_set)


def _read_lower_segments(floor_el):
    """Читает нижние лонжероны → список (x1, y1, x2, y2)."""
    ids = parse_ids_from_string(get_string_param(floor_el, P.STRINGERS_BOTTOM_ID))
    segs = []
    for int_id in ids:
        el = doc.GetElement(ElementId(int_id))
        if el is None:
            continue
        loc = el.Location
        if loc is None:
            continue
        curve = loc.Curve
        p0 = curve.GetEndPoint(0)
        p1 = curve.GetEndPoint(1)
        segs.append((_rc(p0.X), _rc(p0.Y), _rc(p1.X), _rc(p1.Y)))
    return segs


def _get_lower_axis_and_angle(lower_segs):
    """Возвращает ось нижних лонжеронов и угол поворота стойки.

    Нижние в проекте идут одним набором параллельных сегментов,
    поэтому достаточно первого валидного сегмента:
      - по X  -> угол 0
      - по Y  -> угол pi/2
    """
    for x1, y1, x2, y2 in lower_segs:
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        if dx < COORD_TOL and dy < COORD_TOL:
            continue
        if dx >= dy:
            return "X", 0.0
        return "Y", math.pi / 2.0
    return "X", 0.0


def _generate_support_nodes(
    lower_segs, max_spacing, support_half=0.0, grid_positions=None
):
    """Генерация узлов стоек вдоль нижних лонжеронов (shared logic)."""
    return build_support_nodes(
        lower_segs,
        max_spacing,
        support_half=support_half,
        tol=COORD_TOL,
        grid_positions=grid_positions,
    )


try:
    doc = get_doc()
    uidoc = get_uidoc()
    view = get_active_view()

    if not doc or not uidoc:
        raise Exception(tr("source_floor_not_found"))

    if not isinstance(view, ViewPlan):
        forms.alert(tr("open_plan"), title=TITLE)
        raise _Cancel()

    pick_filter = FloorOrPartSelectionFilter()
    try:
        ref = uidoc.Selection.PickObject(
            ObjectType.Element,
            pick_filter,
            tr("pick_floor_prompt"),
        )
    except OperationCanceledException:
        raise _Cancel()

    picked_el = doc.GetElement(ref.ElementId)
    floor = get_source_floor(picked_el)
    if not floor:
        raise Exception(tr("source_floor_not_found"))

    # Семейство стоек
    support_symbols = _get_family_symbols(FAMILY_SUPPORT)
    if not support_symbols:
        forms.alert(
            tr("supports_family_missing", family=FAMILY_SUPPORT),
            title=TITLE,
        )
        raise _Cancel()

    if len(support_symbols) == 1:
        sym_support = support_symbols[0]
    else:
        sup_dict = {}
        for s in support_symbols:
            try:
                name = s.Name
            except Exception:
                name = str(s.Id.Value)
            sup_dict[name] = s
        chosen_sup = forms.CommandSwitchWindow.show(
            sorted(sup_dict.keys()),
            message=tr("supports_type_message"),
        )
        if not chosen_sup:
            raise _Cancel()
        sym_support = sup_dict[chosen_sup]

    # Спросить мин. шаг стоек
    s_spacing = forms.ask_for_string(
        prompt=tr("prompt_support_spacing"),
        default=str(int(DEFAULT_SUPPORT_SPACING_MM)),
        title=TITLE,
    )
    if not s_spacing:
        raise _Cancel()
    try:
        min_spacing = mm_to_internal(float(s_spacing.strip()))
    except ValueError:
        forms.alert(tr("invalid_number"), title=TITLE)
        raise _Cancel()

    # Чтение данных
    lower_segs = _read_lower_segments(floor)
    if not lower_segs:
        forms.alert(
            tr("lower_longerons_missing"),
            title=TITLE,
        )
        raise _Cancel()
    lower_axis, support_angle = _get_lower_axis_and_angle(lower_segs)

    v_keys, h_keys = _read_grid_lines(floor)

    # --- Система высот ---
    profile_h_upper = 0.0
    profile_h_lower = 0.0

    upper_ids_str = get_string_param(floor, P.STRINGERS_TOP_ID)
    upper_longeron_ids = parse_ids_from_string(upper_ids_str)
    if not upper_longeron_ids:
        proceed = forms.alert(
            tr("supports_upper_missing"),
            title=TITLE,
            yes=True,
            no=True,
        )
        if not proceed:
            raise _Cancel()

    if upper_longeron_ids:
        first_el = doc.GetElement(ElementId(upper_longeron_ids[0]))
        if first_el:
            t = doc.GetElement(first_el.GetTypeId())
            if t:
                profile_h_upper = get_double_param(t, P.PROFILE_HEIGHT) or 0.0

    lower_longeron_ids = parse_ids_from_string(
        get_string_param(floor, P.STRINGERS_BOTTOM_ID)
    )
    if lower_longeron_ids:
        first_el = doc.GetElement(ElementId(lower_longeron_ids[0]))
        if first_el:
            t = doc.GetElement(first_el.GetTypeId())
            if t:
                profile_h_lower = get_double_param(t, P.PROFILE_HEIGHT) or 0.0

    total_h = get_double_param(floor, P.FLOOR_HEIGHT) or 0.0
    tile_t = get_double_param(floor, P.TILE_THICKNESS) or 0.0
    if tile_t <= COORD_TOL:
        tile_t = _get_tile_thickness_fallback()

    if total_h > 0:
        support_h = total_h - tile_t - profile_h_upper - profile_h_lower
        if support_h < -COORD_TOL:
            forms.alert(
                tr("supports_height_conflict"),
                title=TITLE,
            )
            raise _Cancel()
        support_h = max(0.0, support_h)
    else:
        support_h = 0.0

    _h_diag = tr(
        "supports_height_diag",
        total=internal_to_mm(total_h),
        tile=internal_to_mm(tile_t),
        upper=internal_to_mm(profile_h_upper),
        lower=internal_to_mm(profile_h_lower),
        support=internal_to_mm(support_h),
    )

    # Генерация узлов стоек
    base_size = get_double_param(sym_support, P.BASE_SIZE) or 0.0
    support_half = base_size / 2.0
    # Перпендикулярные линии сетки для выравнивания стоек в ряд
    if lower_axis == "X":
        grid_pos = v_keys  # вертикальные линии перпендикулярны стрингерам по X
    else:
        grid_pos = h_keys  # горизонтальные линии перпендикулярны стрингерам по Y
    support_nodes = _generate_support_nodes(
        lower_segs, min_spacing, support_half, grid_positions=grid_pos
    )

    # Индексы колонка/ряд для стоек
    def _nearest_idx(keys, val):
        best_i, best_d = 0, float("inf")
        for i, k in enumerate(keys):
            d = abs(k - val)
            if d < best_d:
                best_d = d
                best_i = i
        return best_i

    # Level
    level_id = floor.LevelId
    if level_id and level_id != ElementId.InvalidElementId:
        level = doc.GetElement(level_id)
    else:
        level = view.GenLevel

    if not level:
        forms.alert(tr("open_plan"), title=TITLE)
        raise _Cancel()

    # Z стойки = верх перекрытия (стойка стоит на плите)
    bbox_data = get_bbox_xy(floor, view)
    z0_abs = bbox_data[5] if bbox_data else 0.0
    level_elevation = level.Elevation if hasattr(level, "Elevation") else 0.0
    z0 = z0_abs - level_elevation

    # Подтверждение
    old_ids = parse_ids_from_string(get_string_param(floor, P.SUPPORTS_ID))

    msg = [
        tr("supports_count", count=len(support_nodes)),
        tr("supports_lower_count", count=len(lower_segs)),
        tr("supports_axis", axis=lower_axis),
        tr("supports_min_spacing", spacing=internal_to_mm(min_spacing)),
    ]
    if base_size > 0:
        msg.append(tr("supports_base", size=internal_to_mm(base_size)))
    if support_h > 0:
        msg.append(tr("supports_height", height=internal_to_mm(support_h)))
    else:
        msg.append(tr("supports_height_zero"))
    msg.append("")
    msg.append(_h_diag)
    msg.extend(
        [
            "",
            tr("supports_delete_old", count=len(old_ids)),
            "",
            tr("continue"),
        ]
    )
    confirm = forms.alert(
        "\n".join(msg),
        title=TITLE,
        yes=True,
        no=True,
    )
    if not confirm:
        raise _Cancel()

    # Размещение
    with revit.Transaction(tr("tx_place_supports")):
        if not sym_support.IsActive:
            sym_support.Activate()
            doc.Regenerate()

        deleted = 0
        for int_id in old_ids:
            try:
                el = doc.GetElement(ElementId(int_id))
                if el:
                    doc.Delete(ElementId(int_id))
                    deleted += 1
            except Exception:
                pass

        placed_ids = []
        s_count = 0
        for sx, sy in support_nodes:
            inst = doc.Create.NewFamilyInstance(
                XYZ(sx, sy, z0),
                sym_support,
                level,
                StructuralType.NonStructural,
            )
            if abs(support_angle) > 1e-9:
                axis = Line.CreateBound(XYZ(sx, sy, z0), XYZ(sx, sy, z0 + 1.0))
                ElementTransformUtils.RotateElement(doc, inst.Id, axis, support_angle)
            s_count += 1
            col = _nearest_idx(v_keys, sx)
            row = _nearest_idx(h_keys, sy)
            _set_param(inst, P.COLUMN, col)
            _set_param(inst, P.ROW, row)
            _set_param(inst, P.MARK, "СТ.{}".format(s_count))
            if support_h > 0:
                _set_param(inst, P.SUPPORT_HEIGHT, support_h)
            placed_ids.append(str(inst.Id.Value))

        set_string_param(floor, P.SUPPORTS_ID, ";".join(placed_ids))

    report = tr("supports_done", count=s_count, deleted=deleted)
    report += "\n" + tr("supports_axis", axis=lower_axis)
    if support_h > 0:
        report += "\n" + tr("supports_height", height=internal_to_mm(support_h))
    forms.alert(report, title=TITLE)

except _Cancel:
    pass
except Exception as ex:
    forms.alert(tr("error_inline_fmt", error=str(ex)), title=TITLE)
